# NFC-Reader
An Simple Android APP to read NFC tags: UUID, URL, Data type, Manufacturing info...

--------------------------------------------------------
This is a modified version of the above mentioned NFC Reader
This application is designed to detect URL from the tag and 
perform blacklisting on it to identify whether the URL is malicious
or not.
------------------------------------------
