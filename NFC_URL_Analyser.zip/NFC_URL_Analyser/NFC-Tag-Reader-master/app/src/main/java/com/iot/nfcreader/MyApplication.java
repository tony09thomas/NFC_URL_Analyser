package com.iot.nfcreader;

import android.app.Application;
import android.support.multidex.MultiDexApplication;

import java.net.MulticastSocket;

public class MyApplication extends MultiDexApplication {
}
