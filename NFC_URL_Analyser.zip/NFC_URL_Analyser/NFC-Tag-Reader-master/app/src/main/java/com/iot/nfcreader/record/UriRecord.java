/*
 * Copyright (C) 2016 Joey
 *
 */
package com.iot.nfcreader.record;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.iot.nfcreader.R;
import android.app.Activity;
import android.graphics.Color;
import android.net.Uri;
import android.nfc.NdefRecord;
import android.text.util.Linkify;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.common.base.Preconditions;
import com.google.common.collect.BiMap;
import com.google.common.collect.ImmutableBiMap;
import com.google.common.primitives.Bytes;

/**
 * A parsed record containing a Uri.
 */
public class UriRecord implements ParsedNdefRecord {

    private static final String TAG = "UriRecord";

    public static final String RECORD_TYPE = "UriRecord";

    /**
     * NFC Forum "URI Record Type Definition"
     *
     * This is a mapping of "URI Identifier Codes" to URI string prefixes,
     * per section 3.2.2 of the NFC Forum URI Record Type Definition document.
     */
    private static final BiMap<Byte, String> URI_PREFIX_MAP = ImmutableBiMap.<Byte, String>builder()
            .put((byte) 0x00, "")
            .put((byte) 0x01, "http://www.")
            .put((byte) 0x02, "https://www.")
            .put((byte) 0x03, "http://")
            .put((byte) 0x04, "https://")
            .put((byte) 0x05, "tel:")
            .put((byte) 0x06, "mailto:")
            .put((byte) 0x07, "ftp://anonymous:anonymous@")
            .put((byte) 0x08, "ftp://ftp.")
            .put((byte) 0x09, "ftps://")
            .put((byte) 0x0A, "sftp://")
            .put((byte) 0x0B, "smb://")
            .put((byte) 0x0C, "nfs://")
            .put((byte) 0x0D, "ftp://")
            .put((byte) 0x0E, "dav://")
            .put((byte) 0x0F, "news:")
            .put((byte) 0x10, "telnet://")
            .put((byte) 0x11, "imap:")
            .put((byte) 0x12, "rtsp://")
            .put((byte) 0x13, "urn:")
            .put((byte) 0x14, "pop:")
            .put((byte) 0x15, "sip:")
            .put((byte) 0x16, "sips:")
            .put((byte) 0x17, "tftp:")
            .put((byte) 0x18, "btspp://")
            .put((byte) 0x19, "btl2cap://")
            .put((byte) 0x1A, "btgoep://")
            .put((byte) 0x1B, "tcpobex://")
            .put((byte) 0x1C, "irdaobex://")
            .put((byte) 0x1D, "file://")
            .put((byte) 0x1E, "urn:epc:id:")
            .put((byte) 0x1F, "urn:epc:tag:")
            .put((byte) 0x20, "urn:epc:pat:")
            .put((byte) 0x21, "urn:epc:raw:")
            .put((byte) 0x22, "urn:epc:")
            .put((byte) 0x23, "urn:nfc:")
            .build();

    private final Uri mUri;

    private UriRecord(Uri uri) {
        this.mUri = Preconditions.checkNotNull(uri);
    }

    public View getView(Activity activity, LayoutInflater inflater, ViewGroup parent, int offset) {
        TextView text = (TextView) inflater.inflate(R.layout.tag_text, parent, false);
        text.setAutoLinkMask(Linkify.ALL);
        text.setText(mUri.toString());

        Toast.makeText(activity, "Uri record", Toast.LENGTH_SHORT).show();

        if(check_safe_or_not(text).equals("W")){

         //   text.setCompoundDrawablesWithIntrinsicBounds(0,0,R.drawable.ic_check_mark,0);
            text.setBackgroundColor(Color.parseColor("#B0FC58"));


        }
        else {

            text.setBackgroundColor(Color.parseColor("#FF9595"));

        }
        return text;
    }

    private static String check_safe_or_not(TextView text) {

        List<String> blacklist = new ArrayList<>();

        blacklist.add("https://www.goog.com");
        blacklist.add("http://www.goog.com");
        blacklist.add("www.goog.com");
        blacklist.add("http://americanexpress.com.service.rswx.info");
        blacklist.add("http://americanexpress.com-en.identity-info.tk");
        blacklist.add("http://accounts-googlc.com");
        blacklist.add("http://account-spotifyupdt.com");
        blacklist.add("http://account-verfied.blogspot.com");
        blacklist.add("http://acquitted-nulls.000webhostapp.com");
        blacklist.add("http://acsrescures.000webhostapp.com");
        blacklist.add("alexponcet.com");
        blacklist.add("alexpopow.com");
        blacklist.add("alexprivate.tinhost.ru");
        blacklist.add("alexrbn.com");
        blacklist.add("alexressa.com");
        blacklist.add("alexrice.co.uk");
        blacklist.add("alexroadphotography.com.au");
        blacklist.add("alexrockblog.thats.im");
        blacklist.add("alexrubalcava.com");
        blacklist.add("alexsteadphotos.com");
        blacklist.add("alexxrvra.com");
        blacklist.add("alexzangeneh.com");
        blacklist.add("alexzstroy.ru");
        blacklist.add("alfaaizenterprises.com");
        blacklist.add("alfabankovo.ru");
        blacklist.add("alfabeauty.co.id");
        blacklist.add("alfacard.com");
        blacklist.add("alfachemllc.com");
        blacklist.add("alfaclasses.com");
        blacklist.add("alfaclassicos.com");
        blacklist.add("alfacomercial.com.br");
        blacklist.add("alfacrewing.lt");
        blacklist.add("alfacr.pl");
        blacklist.add("alfactiv.com");
        blacklist.add("alfa-galaxy.ru");
        blacklist.add("alfaherbsegypt.com");
        blacklist.add("alfaizan.org");
        blacklist.add("alfajermarine.com");
        blacklist.add("alfalahchemicals.com");
        blacklist.add("al-falah.ir");
        blacklist.add("alfalakgifts.com");
        blacklist.add("alfalfatoivy.com");
        blacklist.add("alfalub.com.br");
        blacklist.add("alfamar.pt");
        blacklist.add("alfaproductos.com");
        blacklist.add("alfaromeopassione.com");
        blacklist.add("alfarotulos.com");
        blacklist.add("alfascientificbd.com");
        blacklist.add("alfasicdehonduras.org.hn");
        blacklist.add("alfasylah.com");
        blacklist.add("alfatek-intelligence.com");
        blacklist.add("alfateksolutions.com");
        blacklist.add("alfatile.com");
        blacklist.add("alfatra.com");
        blacklist.add("alfaturkey.com.tr");
        blacklist.add("alfaturturismorp.com.br");
        blacklist.add("alfa-yachts.com");
        blacklist.add("alfayrouz-eg.com");
        blacklist.add("alfeeltrading.com");
        blacklist.add("alfemimoda.com");
        blacklist.add("alfilodelaverdad.com");
        blacklist.add("alfirustam.id");
        blacklist.add("alfisaliah.com");
        blacklist.add("alfisilver.com");
        blacklist.add("alfjamesandsons.co.uk");
        blacklist.add("alfomindomitrasukses.com");
        blacklist.add("alfonsipianoforti.it");
        blacklist.add("alfonsobrooks.com");
        blacklist.add("alfransia.com");
        blacklist.add("alfredbusinessltd.flu.cc");
        blacklist.add("alfredean.com");
        blacklist.add("alfredo8752.pdns.cz");
        blacklist.add("alfredoposada.com");
        blacklist.add("alfredosfeir.cl");
        blacklist.add("alfredovallejo.com");
        blacklist.add("alfredphotography.co.za");
        blacklist.add("alfredsrobygg.se");
        blacklist.add("alfreepdf.site");
        blacklist.add("algaealliance.com");
        blacklist.add("algaecompetition.com");
        blacklist.add("algaesalud.com");
        blacklist.add("alga.lt");
        blacklist.add("alganixpest.com");
        blacklist.add("algarsl.com");
        blacklist.add("algarvesup.com");
        blacklist.add("algarvetoastmastersclub.com");
        blacklist.add("algerie-focus.com");
        blacklist.add("algerroads.org");
        blacklist.add("alghaithtrd.ae");
        blacklist.add("algidgearset.online");
        blacklist.add("algifo.ml");
        blacklist.add("asdexpress.ru");
        blacklist.add("artof-doing.tk");
        blacklist.add("artofexcellence.org");
        blacklist.add("artoffice.pl");
        blacklist.add("artontheside.com");
        blacklist.add("artopiastudiosinc.com");
        blacklist.add("artpercent.com");
        blacklist.add("art.perniagaan.com");
        blacklist.add("artplast.uz");
        blacklist.add("https://www.goog.com");
        blacklist.add("http://www.goog.com");
        blacklist.add("www.goog.com");
        blacklist.add("http://americanexpress.com.service.rswx.info");
        blacklist.add("http://americanexpress.com-en.identity-info.tk");
        blacklist.add("http://accounts-googlc.com");
        blacklist.add("http://account-spotifyupdt.com");
        blacklist.add("http://account-verfied.blogspot.com");
        blacklist.add("http://acquitted-nulls.000webhostapp.com");
        blacklist.add("http://acsrescures.000webhostapp.com");
        blacklist.add("alexponcet.com");
        blacklist.add("alexpopow.com");
        blacklist.add("alexprivate.tinhost.ru");
        blacklist.add("alexrbn.com");
        blacklist.add("alexressa.com");
        blacklist.add("alexrice.co.uk");
        blacklist.add("alexroadphotography.com.au");
        blacklist.add("alexrockblog.thats.im");
        blacklist.add("alexrubalcava.com");
        blacklist.add("alexsteadphotos.com");
        blacklist.add("alexxrvra.com");
        blacklist.add("alexzangeneh.com");
        blacklist.add("alexzstroy.ru");
        blacklist.add("alfaaizenterprises.com");
        blacklist.add("alfabankovo.ru");
        blacklist.add("alfabeauty.co.id");
        blacklist.add("alfacard.com");
        blacklist.add("alfachemllc.com");
        blacklist.add("alfaclasses.com");
        blacklist.add("alfaclassicos.com");
        blacklist.add("alfacomercial.com.br");
        blacklist.add("alfacrewing.lt");
        blacklist.add("alfacr.pl");
        blacklist.add("alfactiv.com");
        blacklist.add("alfa-galaxy.ru");
        blacklist.add("alfaherbsegypt.com");
        blacklist.add("alfaizan.org");
        blacklist.add("alfajermarine.com");
        blacklist.add("alfalahchemicals.com");
        blacklist.add("al-falah.ir");
        blacklist.add("alfalakgifts.com");
        blacklist.add("alfalfatoivy.com");
        blacklist.add("alfalub.com.br");
        blacklist.add("alfamar.pt");
        blacklist.add("alfaproductos.com");
        blacklist.add("alfaromeopassione.com");
        blacklist.add("alfarotulos.com");
        blacklist.add("alfascientificbd.com");
        blacklist.add("alfasicdehonduras.org.hn");
        blacklist.add("alfasylah.com");
        blacklist.add("alfatek-intelligence.com");
        blacklist.add("alfateksolutions.com");
        blacklist.add("alfatile.com");
        blacklist.add("alfatra.com");
        blacklist.add("alfaturkey.com.tr");
        blacklist.add("alfaturturismorp.com.br");
        blacklist.add("alfa-yachts.com");
        blacklist.add("alfayrouz-eg.com");
        blacklist.add("alfeeltrading.com");
        blacklist.add("alfemimoda.com");
        blacklist.add("alfilodelaverdad.com");
        blacklist.add("alfirustam.id");
        blacklist.add("alfisaliah.com");
        blacklist.add("alfisilver.com");
        blacklist.add("alfjamesandsons.co.uk");
        blacklist.add("alfomindomitrasukses.com");
        blacklist.add("alfonsipianoforti.it");
        blacklist.add("alfonsobrooks.com");
        blacklist.add("alfransia.com");
        blacklist.add("alfredbusinessltd.flu.cc");
        blacklist.add("alfredean.com");
        blacklist.add("alfredo8752.pdns.cz");
        blacklist.add("alfredoposada.com");
        blacklist.add("alfredosfeir.cl");
        blacklist.add("alfredovallejo.com");
        blacklist.add("alfredphotography.co.za");
        blacklist.add("alfredsrobygg.se");
        blacklist.add("alfreepdf.site");
        blacklist.add("algaealliance.com");
        blacklist.add("algaecompetition.com");
        blacklist.add("algaesalud.com");
        blacklist.add("alga.lt");
        blacklist.add("alganixpest.com");
        blacklist.add("algarsl.com");
        blacklist.add("algarvesup.com");
        blacklist.add("algarvetoastmastersclub.com");
        blacklist.add("algerie-focus.com");
        blacklist.add("algerroads.org");
        blacklist.add("alghaithtrd.ae");
        blacklist.add("algidgearset.online");
        blacklist.add("algifo.ml");
        blacklist.add("asdexpress.ru");
        blacklist.add("artof-doing.tk");
        blacklist.add("artofexcellence.org");
        blacklist.add("artoffice.pl");
        blacklist.add("artontheside.com");
        blacklist.add("artopiastudiosinc.com");
        blacklist.add("artpercent.com");
        blacklist.add("art.perniagaan.com");
        blacklist.add("artplast.uz");
        blacklist.add("artplast.uz");
        blacklist.add("https://www.goog.com");
        blacklist.add("http://www.goog.com");
        blacklist.add("www.goog.com");
        blacklist.add("http://americanexpress.com.service.rswx.info");
        blacklist.add("http://americanexpress.com-en.identity-info.tk");
        blacklist.add("http://accounts-googlc.com");
        blacklist.add("http://account-spotifyupdt.com");
        blacklist.add("http://account-verfied.blogspot.com");
        blacklist.add("http://acquitted-nulls.000webhostapp.com");
        blacklist.add("http://acsrescures.000webhostapp.com");
        blacklist.add("alexponcet.com");
        blacklist.add("alexpopow.com");
        blacklist.add("alexprivate.tinhost.ru");
        blacklist.add("alexrbn.com");
        blacklist.add("alexressa.com");
        blacklist.add("alexrice.co.uk");
        blacklist.add("alexroadphotography.com.au");
        blacklist.add("alexrockblog.thats.im");
        blacklist.add("alexrubalcava.com");
        blacklist.add("alexsteadphotos.com");
        blacklist.add("alexxrvra.com");
        blacklist.add("alexzangeneh.com");
        blacklist.add("alexzstroy.ru");
        blacklist.add("alfaaizenterprises.com");
        blacklist.add("alfabankovo.ru");
        blacklist.add("alfabeauty.co.id");
        blacklist.add("alfacard.com");
        blacklist.add("alfachemllc.com");
        blacklist.add("alfaclasses.com");
        blacklist.add("alfaclassicos.com");
        blacklist.add("alfacomercial.com.br");
        blacklist.add("alfacrewing.lt");
        blacklist.add("alfacr.pl");
        blacklist.add("alfactiv.com");
        blacklist.add("alfa-galaxy.ru");
        blacklist.add("alfaherbsegypt.com");
        blacklist.add("alfaizan.org");
        blacklist.add("alfajermarine.com");
        blacklist.add("alfalahchemicals.com");
        blacklist.add("al-falah.ir");
        blacklist.add("alfalakgifts.com");
        blacklist.add("alfalfatoivy.com");
        blacklist.add("alfalub.com.br");
        blacklist.add("alfamar.pt");
        blacklist.add("alfaproductos.com");
        blacklist.add("alfaromeopassione.com");
        blacklist.add("alfarotulos.com");
        blacklist.add("alfascientificbd.com");
        blacklist.add("alfasicdehonduras.org.hn");
        blacklist.add("alfasylah.com");
        blacklist.add("alfatek-intelligence.com");
        blacklist.add("alfateksolutions.com");
        blacklist.add("alfatile.com");
        blacklist.add("alfatra.com");
        blacklist.add("alfaturkey.com.tr");
        blacklist.add("alfaturturismorp.com.br");
        blacklist.add("alfa-yachts.com");
        blacklist.add("alfayrouz-eg.com");
        blacklist.add("alfeeltrading.com");
        blacklist.add("alfemimoda.com");
        blacklist.add("alfilodelaverdad.com");
        blacklist.add("alfirustam.id");
        blacklist.add("alfisaliah.com");
        blacklist.add("alfisilver.com");blacklist.add("alfalakgifts.com");
        blacklist.add("alfalfatoivy.com");
        blacklist.add("alfalub.com.br");
        blacklist.add("alfamar.pt");
        blacklist.add("alfaproductos.com");
        blacklist.add("alfaromeopassione.com");
        blacklist.add("alfarotulos.com");
        blacklist.add("alfascientificbd.com");
        blacklist.add("alfasicdehonduras.org.hn");
        blacklist.add("alfasylah.com");
        blacklist.add("alfatek-intelligence.com");
        blacklist.add("alfateksolutions.com");
        blacklist.add("alfatile.com");
        blacklist.add("alfatra.com");
        blacklist.add("alfaturkey.com.tr");
        blacklist.add("alfaturturismorp.com.br");
        blacklist.add("alfa-yachts.com");
        blacklist.add("alfayrouz-eg.com");
        blacklist.add("alfeeltrading.com");
        blacklist.add("alfemimoda.com");
        blacklist.add("alfilodelaverdad.com");
        blacklist.add("alfirustam.id");
        blacklist.add("alfisaliah.com");
        blacklist.add("alfisilver.com");
        blacklist.add("alfjamesandsons.co.uk");
        blacklist.add("alfomindomitrasukses.com");
        blacklist.add("alfonsipianoforti.it");
        blacklist.add("alfonsobrooks.com");
        blacklist.add("alfransia.com");
        blacklist.add("alfredbusinessltd.flu.cc");
        blacklist.add("alfredean.com");
        blacklist.add("alfredo8752.pdns.cz");
        blacklist.add("alfredoposada.com");
        blacklist.add("alfredosfeir.cl");
        blacklist.add("alfredovallejo.com");
        blacklist.add("alfredphotography.co.za");
        blacklist.add("alfredsrobygg.se");
        blacklist.add("alfreepdf.site");
        blacklist.add("algaealliance.com");
        blacklist.add("algaecompetition.com");
        blacklist.add("algaesalud.com");
        blacklist.add("alga.lt");
        blacklist.add("alganixpest.com");
        blacklist.add("algarsl.com");
        blacklist.add("algarvesup.com");
        blacklist.add("algarvetoastmastersclub.com");
        blacklist.add("algerie-focus.com");
        blacklist.add("algerroads.org");
        blacklist.add("alghaithtrd.ae");
        blacklist.add("algidgearset.online");
        blacklist.add("algifo.ml");
        blacklist.add("asdexpress.ru");
        blacklist.add("artof-doing.tk");
        blacklist.add("artofexcellence.org");
        blacklist.add("artoffice.pl");
        blacklist.add("artontheside.com");
        blacklist.add("artopiastudiosinc.com");
        blacklist.add("artpercent.com");
        blacklist.add("art.perniagaan.com");
        blacklist.add("artontheside.com");
        blacklist.add("artontheside.com");
        blacklist.add("https://malicioussite101.000webhostapp.com/");


        for(int i=0;i<blacklist.size();i++){
            if(text.getText().toString().trim().equals(blacklist.get(i))){

                return "B";






            }

        }

        return  "W";

    }

    public Uri getUri() {
        return mUri;
    }

    /**
     * Convert {@link android.nfc.NdefRecord} into a {@link android.net.Uri}.
     * This will handle both TNF_WELL_KNOWN / RTD_URI and TNF_ABSOLUTE_URI.
     *
     * @throws IllegalArgumentException if the NdefRecord is not a record
     *         containing a URI.
     */
    public static UriRecord parse(NdefRecord record) {
        short tnf = record.getTnf();
        if (tnf == NdefRecord.TNF_WELL_KNOWN) {
            return parseWellKnown(record);
        } else if (tnf == NdefRecord.TNF_ABSOLUTE_URI) {
            return parseAbsolute(record);
        }
        throw new IllegalArgumentException("Unknown TNF " + tnf);
    }

    /** Parse and absolute URI record */
    private static UriRecord parseAbsolute(NdefRecord record) {
        byte[] payload = record.getPayload();
        Uri uri = Uri.parse(new String(payload, Charset.forName("UTF-8")));
        return new UriRecord(uri);
    }

    /** Parse an well known URI record */
    private static UriRecord parseWellKnown(NdefRecord record) {
        Preconditions.checkArgument(Arrays.equals(record.getType(), NdefRecord.RTD_URI));
        byte[] payload = record.getPayload();
        /*
         * payload[0] contains the URI Identifier Code, per the
         * NFC Forum "URI Record Type Definition" section 3.2.2.
         *
         * payload[1]...payload[payload.length - 1] contains the rest of
         * the URI.
         */
        String prefix = URI_PREFIX_MAP.get(payload[0]);
        byte[] fullUri =
            Bytes.concat(prefix.getBytes(Charset.forName("UTF-8")), Arrays.copyOfRange(payload, 1,
                payload.length));
        Uri uri = Uri.parse(new String(fullUri, Charset.forName("UTF-8")));
        return new UriRecord(uri);
    }

    public static boolean isUri(NdefRecord record) {
        try {
            parse(record);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    private static final byte[] EMPTY = new byte[0];
}
